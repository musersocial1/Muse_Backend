const twilio = require("twilio");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
//const axios = require("axios");
const crypto = require("crypto");
const User = require("../model/user");
const VerificationCode = require("../model/code");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const verifyServiceSid = process.env.TWILIO_VERIFY_SERVICE_SID;

const client = twilio(accountSid, authToken);

exports.sendVerificationCode = async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    if (!phoneNumber)
      return res.status(400).json({ message: "Phone number is required." });

    await client.verify.v2
      .services(verifyServiceSid)
      .verifications.create({ to: phoneNumber, channel: "sms" });

    return res.status(200).json({ message: "Phone verification code sent." });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to send verification code.",
      error: error.message,
    });
  }
};

exports.resendVerificationCode = async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    if (!phoneNumber)
      return res.status(400).json({ message: "Phone number is required." });

    await client.verify.v2
      .services(verifyServiceSid)
      .verifications.create({ to: phoneNumber, channel: "sms" });

    return res.status(200).json({ message: "Phone verification code resent." });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to send verification code.",
      error: error.message,
    });
  }
};

exports.verifyPhoneCode = async (req, res) => {
  try {
    const { phoneNumber, code } = req.body;
    if (!phoneNumber || !code) {
      return res
        .status(400)
        .json({ message: "Phone number and code are required." });
    }

    const verificationCheck = await client.verify.v2
      .services(verifyServiceSid)
      .verificationChecks.create({ to: phoneNumber, code });

    if (verificationCheck.status === "approved") {
      return res.status(200).json({ message: "Phone number verified!" });
    } else {
      return res.status(400).json({ message: "Incorrect verification code." });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Verification failed.", error: error.message });
  }
};

/*exports.sendVerificationCode = async (req, res) => {
  const { phoneNumber } = req.body;
    if (!phoneNumber) {
      return res.status(400).json({ message: "Phone number is required." });
    }

    await VerificationCode.deleteMany({ phoneNumber });

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    const url = "https://graph.facebook.com/v22.0/764377226749149/messages";
    const accessToken = process.env.WHATSAPP_ACCESS_TOKEN;

    const payload = {
      messaging_product: "whatsapp",
      to: phoneNumber.replace(/^\+/, ""),
      type: "template",
      template: {
        name: "muse_otp",
        language: { code: "en_US" },
        components: [
          {
            type: "body",
            parameters: [{ type: "text", text: code }],
          },
          {
            type: "button",
            sub_type: "url",
            index: 0,
            parameters: [
              { type: "text", text: "Muse Verification" },
            ],
          },
          {
            type: "button",
            sub_type: "url",
            index: 1,
            parameters: [
              { type: "text", text: "Copy Muse Code" }
            ]
          }
        ],
      },
    };

    try {
      await axios.post(url, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      });
  
      await VerificationCode.create({
        phoneNumber,
        code,
        expiresAt,
        used: false,
      });
  
      return res
        .status(200)
        .json({ message: "WhatsApp verification code sent.", code });
    } catch (waError) {
      try {
        await client.verify.v2
          .services(verifyServiceSid)
          .verifications.create({ to: phoneNumber, channel: "sms" });
  
        return res.status(200).json({ message: "Twilio verification code sent." });
      } catch (smsError) {
        return res.status(500).json({
          message: "Failed to send code via WhatsApp and SMS.",
          whatsapp: waError.response?.data || waError.message,
          sms: smsError.message
        });
      }
    }
};

exports.resendVerificationCode = async (req, res) => {
  const { phoneNumber } = req.body;
  if (!phoneNumber) {
    return res.status(400).json({ message: "Phone number is required." });
  }

  const latestCode = await VerificationCode.findOne({ phoneNumber }).sort({ createdAt: -1 });
  if (latestCode) {
    const now = Date.now();
    const sentTime = new Date(latestCode.createdAt).getTime();
    if (now - sentTime < 60 * 1000) {
      const secondsLeft = Math.ceil((60 * 1000 - (now - sentTime)) / 1000);
      return res.status(429).json({
        message: `Please wait ${secondsLeft}s before requesting another code.`,
      });
    }
  }

  await VerificationCode.deleteMany({ phoneNumber });

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

  const url = "https://graph.facebook.com/v22.0/764377226749149/messages";
  const accessToken = process.env.WHATSAPP_ACCESS_TOKEN;

  const payload = {
    messaging_product: "whatsapp",
    to: phoneNumber.replace(/^\+/, ""),
    type: "template",
    template: {
      name: "muse_otp",
      language: { code: "en_US" },
      components: [
        {
          type: "body",
          parameters: [{ type: "text", text: code }],
        },
        {
          type: "button",
          sub_type: "url",
          index: 0,
          parameters: [{ type: "text", text: "Muse Verification" }],
        },
        {
          type: "button",
          sub_type: "url",
          index: 1,
          parameters: [{ type: "text", text: "Copy Muse Code" }]
        }
      ],
    },
  };

  try {
    await axios.post(url, payload, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    });

    await VerificationCode.create({
      phoneNumber,
      code,
      expiresAt,
      used: false,
    });

    return res.status(200).json({
      message: "WhatsApp verification code resent.",
      code,
    });
  } catch (waError) {
    try {
      await client.verify.v2
        .services(verifyServiceSid)
        .verifications.create({ to: phoneNumber, channel: "sms" });

      return res.status(200).json({ message: "Twilio SMS verification code resent." });
    } catch (smsError) {
      return res.status(500).json({
        message: "Failed to resend code via WhatsApp and SMS.",
        whatsapp: waError.response?.data || waError.message,
        sms: smsError.message,
      });
    }
  }
};

exports.verifyPhoneCode = async (req, res) => {
  try {
    const { phoneNumber, code } = req.body;
    if (!phoneNumber || !code) {
      return res.status(400).json({ message: "Phone number and code are required." });
    }

    const verification = await VerificationCode.findOne({
      phoneNumber,
      code,
      expiresAt: { $gt: new Date() },
      used: false,
    });

    if (verification) {
      verification.used = true;
      await verification.save();

      return res.status(200).json({ message: "Phone number verified! (WhatsApp)" });
    }

    try {
      const verificationCheck = await client.verify.v2
        .services(verifyServiceSid)
        .verificationChecks.create({ to: phoneNumber, code });

      if (verificationCheck.status === "approved") {

        return res.status(200).json({ message: "Phone number verified! (SMS)" });
      } else {
        return res.status(400).json({ message: "Incorrect verification code." });
      }
    } catch (twilioError) {
      return res.status(400).json({ message: "Incorrect or expired verification code." });
    }

  } catch (error) {
    return res
      .status(500)
      .json({ message: "Verification failed.", error: error.message });
  }
};*/

exports.createAccount = async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      username,
      email,
      password,
      confirmPassword,
      dateOfBirth,
      accountType,
      gender,
      interests,
      phoneNumber,
    } = req.body;

    if (
      !firstName ||
      !lastName ||
      !username ||
      !email ||
      !password ||
      !confirmPassword ||
      !dateOfBirth ||
      !accountType ||
      !phoneNumber
    ) {
      return res
        .status(400)
        .json({ message: "All required fields must be provided." });
    }

    const validateEmail = (email) => {
      const regex =
        /^[^\s@]+@[^\s@]+\.(com|net|org|edu|gov|mil|biz|info|mobi|name|aero|jobs|museum|co\.[a-z]{2}|[a-z]{2})$/i;
      return regex.test(email);
    };

    if (!validateEmail(email)) {
      return res.status(400).json({ error: "Invalid email format." });
    }

    const validatePassword = (password) => {
      return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+={}[\]|:;"'<>,.?/~`])[A-Za-z\d!@#$%^&*()_\-+={}[\]|:;"'<>,.?/~`]{8,}$/.test(
        password
      );
    };

    if (!validatePassword(password)) {
      return res.status(400).json({
        error:
          "Password must be at least 8 characters, include an uppercase letter, a lowercase letter, a number, and a special character.",
      });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ error: "Passwords do not match." });
    }

    const usernameExists = await User.findOne({
      username: username.toLowerCase(),
    });
    if (usernameExists) {
      return res.status(409).json({ error: "Username already in use." });
    }

    const emailExists = await User.findOne({ email: email.toLowerCase() });
    if (emailExists) {
      return res.status(409).json({ error: "Email already in use." });
    }

    const phoneExists = await User.findOne({ phoneNumber });
    if (phoneExists) {
      return res.status(409).json({ error: "Phone number already in use." });
    }

    const stripeCustomer = await stripe.customers.create({
      email: email.toLowerCase(),
      name: `${firstName} ${lastName}`,
      phone: phoneNumber,
    });

    const user = new User({
      firstName,
      lastName,
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      password,
      dateOfBirth,
      accountType,
      gender,
      interests,
      phoneNumber,
      isPhoneVerified: true,
      stripeCustomerId: stripeCustomer.id,
    });

    await user.save();

    const generateToken = (user) => {
      return jwt.sign(
        { id: user._id, username: user.username, email: user.email },
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
      );
    };

    const token = generateToken(user);

    const safeUser = user.toObject();
    delete safeUser.password;

    return res
      .status(201)
      .json({ message: "Registration successful.", token, user: safeUser });
  } catch (err) {
    return res
      .status(500)
      .json({ message: "Registration failed.", error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res
        .status(400)
        .json({ error: "Email and password are required." });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(404).json({ error: "User not found." });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(401).json({ error: "Invalid credentials." });

    await VerificationCode.deleteMany({ email });

    //const code = Math.floor(100000 + Math.random() * 900000).toString();
    const code = crypto.randomInt(100000, 999999).toString(); // secure 6-digit code
    const expiresAt = Date.now() + 10 * 60 * 1000;

    await VerificationCode.create({ user: user._id, email, code, expiresAt });

    return res.status(200).json({
      message: "Email verification code sent.",
      email,
      code,
      expiresAt,
    });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ error: "Failed to generate code.", details: error.message });
  }
};

exports.resendCode = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required." });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(404).json({ error: "User not found." });

    // Check for recent (unexpired) code sent in the last 60s
    const existingCode = await VerificationCode.findOne({ email }).sort({
      expiresAt: -1,
    });

    if (
      existingCode &&
      Date.now() - (existingCode.createdAt?.getTime() || 0) < 60 * 1000
    ) {
      const secondsLeft =
        60 - Math.floor((Date.now() - existingCode.createdAt.getTime()) / 1000);
      return res.status(429).json({
        error: `Please wait ${secondsLeft} seconds before resending the code.`,
      });
    }

    await VerificationCode.deleteMany({ email });

    const code = crypto.randomInt(100000, 999999).toString();
    const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes

    await VerificationCode.create({ user: user._id, email, code, expiresAt });

    return res.status(200).json({
      message: "Email verification code resent.",
      email,
      code,
      expiresAt,
    });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ error: "Failed to resend code.", details: error.message });
  }
};

exports.verifyLogin = async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code)
      return res.status(400).json({ error: "Email and code are required." });

    const user = await User.findOne({ email: email.toLowerCase() }).select(
      "-password"
    );
    if (!user) return res.status(404).json({ error: "User not found." });

    const record = await VerificationCode.findOne({
      email,
      code,
      expiresAt: { $gt: new Date() },
    });
    if (!record)
      return res
        .status(400)
        .json({ error: "No verification code found. Please login again." });

    if (record.code !== code)
      return res.status(400).json({ error: "Invalid verification code." });

    if (Date.now() > record.expiry)
      return res.status(400).json({ error: "Verification code expired." });

    await VerificationCode.deleteMany({ email });

    const token = jwt.sign(
      { id: user._id, username: user.username, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    return res.status(200).json({ message: "Login successful.", token, user });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// SETTINGS
exports.getUserProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const user = await User.findById(userId).select("-password");
    if (!user) return res.status(404).json({ error: "User not found." });

    return res.status(200).json({ user });
  } catch (error) {
    return res
      .status(500)
      .json({ error: "Failed to get user profile.", details: error.message });
  }
};

exports.requestChangeEmail = async (req, res) => {
  try {
    const userId = req.user.id;
    const { newEmail } = req.body;

    if (!newEmail) {
      return res.status(400).json({ message: "New email is required." });
    }

    const validateEmail = (email) => {
      const regex =
        /^[^\s@]+@[^\s@]+\.(com|net|org|edu|gov|mil|biz|info|mobi|name|aero|jobs|museum|co\.[a-z]{2}|[a-z]{2})$/i;
      return regex.test(email);
    };

    if (!validateEmail(newEmail)) {
      return res.status(400).json({ error: "Invalid email format." });
    }

    const emailExists = await User.findOne({ email: newEmail.toLowerCase() });
    if (emailExists) {
      return res.status(409).json({ message: "Email already in use." });
    }

    await VerificationCode.deleteMany({ email: newEmail.toLowerCase() });

    const code = crypto.randomInt(100000, 999999).toString();
    const expiresAt = Date.now() + 10 * 60 * 1000;

    // Save or update code with association to user and new email
    await VerificationCode.findOneAndUpdate(
      { user: userId, email: newEmail.toLowerCase() },
      { code, expiresAt },
      { upsert: true, new: true }
    );

    return res.status(200).json({
      message: "Verification code sent to new email.",
      newEmail,
      code,
      expiresAt,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to initiate email change.",
      error: error.message,
    });
  }
};

exports.confirmChangeEmail = async (req, res) => {
  try {
    const userId = req.user.id;
    const { newEmail, code } = req.body;

    if (!newEmail || !code) {
      return res
        .status(400)
        .json({ message: "New email and code are required." });
    }

    const verification = await VerificationCode.findOne({
      user: userId,
      email: newEmail.toLowerCase(),
      code,
    });

    if (!verification) {
      return res.status(400).json({ message: "Invalid verification code." });
    }
    if (verification.expiresAt < Date.now()) {
      return res.status(400).json({ message: "Verification code expired." });
    }

    await User.findByIdAndUpdate(userId, { email: newEmail.toLowerCase() });

    await VerificationCode.deleteMany({
      user: userId,
      email: newEmail.toLowerCase(),
    });

    return res.status(200).json({ message: "Email updated successfully." });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to confirm email change.",
      error: error.message,
    });
  }
};

exports.changeUsername = async (req, res) => {
  try {
    const userId = req.user.id;
    const { newUsername } = req.body;

    if (!newUsername) {
      return res.status(400).json({ message: "New username is required." });
    }

    const existingUser = await User.findOne({
      username: newUsername.toLowerCase(),
    });
    if (existingUser) {
      return res.status(409).json({ message: "Username already exist." });
    }

    // Limit username changes
    const user = await User.findById(userId);
    if (user.usernameChangeCount >= 3) {
      return res
        .status(403)
        .json({ message: "You can only change username 3 times." });
    }

    user.username = newUsername.toLowerCase();
    user.usernameChangeCount += 1;
    await user.save();

    return res.status(200).json({
      message: "Username changed successfully.",
      username: user.username,
      usernameChangeCount: user.usernameChangeCount,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ message: "Failed to change username.", error: error.message });
  }
};

// COMMUNITIES AND SUBSCRIPTION INFO controller functions

exports.requestChangePassword = async (req, res) => {
  try {
    const userId = req.user.id;
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) {
      return res
        .status(400)
        .json({ message: "Old and new password are required." });
    }

    const validatePassword = (password) => {
      return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_\-+={}[\]|:;"'<>,.?/~`])[A-Za-z\d!@#$%^&*()_\-+={}[\]|:;"'<>,.?/~`]{8,}$/.test(
        password
      );
    };

    if (!validatePassword(newPassword)) {
      return res.status(400).json({
        error:
          "Password must be at least 8 characters, include an uppercase letter, a lowercase letter, a number, and a special character.",
      });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found." });

    const isMatch = await bcrypt.compare(oldPassword, user.password);
    if (!isMatch)
      return res.status(401).json({ message: "Old password is incorrect." });

    await VerificationCode.deleteMany({ email: user.email });

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await VerificationCode.create({
      user: user._id,
      email: user.email,
      code,
      expiresAt,
    });

    return res.status(200).json({
      message:
        "OTP code generated. Send this code to the user's email to continue.",
      email: user.email,
      code,
      expiresAt,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Failed to process password change.",
      error: error.message,
    });
  }
};

exports.confirmChangePassword = async (req, res) => {
  try {
    const userId = req.user.id;
    const { newPassword, code } = req.body;

    if (!newPassword || !code) {
      return res
        .status(400)
        .json({ message: "New password and code are required." });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found." });

    const verification = await VerificationCode.findOne({
      user: user._id,
      email: user.email,
      code,
      expiresAt: { $gt: new Date() },
    });

    if (!verification) {
      return res.status(400).json({ message: "Invalid or expired OTP code." });
    }

    user.password = newPassword;
    await user.save();

    return res.status(200).json({ message: "Password changed successfully." });
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ message: "Failed to change password.", error: error.message });
  }
};
